# SC_SEMANTIC_VIEW — SEMANTIC_VIEW() Test Results

**Date**: 2026-10-05
**View**: `SC_ONTOLOGY.SEMANTIC.SC_SEMANTIC_VIEW`
**Role**: ACCOUNTADMIN | **Warehouse**: SC_WH

## Results

| # | Question | Ran | Sensible | Note |
|---|----------|-----|----------|------|
| Q1 | What is the overall on-time delivery rate? | Yes | Yes | 66.9 % — plausible for a mixed carrier portfolio |
| Q2 | What is the on-time rate by customer region? | Yes | Yes | EMEA 67.7 %, APAC 67.6 %, AMER 65.6 % — small spread, reasonable |
| Q3 | What is the fill rate by plant (bottom 10)? | Yes | Yes | Range 0.954–0.966 across plants — high fill, tight band |
| Q4 | What is the average lead time by carrier? | Yes | Yes | BlueDart 16.7 d outlier; others ~12 d — carrier mix effect |
| Q5 | What is the total order value by customer segment? | Yes | Yes | Bronze $1.2 B > Silver $1.0 B > Gold $1.0 B — more Bronze customers |
| Q6 | How many total shipments by supplier country? | Yes | Yes | Thailand 1 408 leads; 5 countries returned — matches 46 suppliers |
| Q7 | What is the total shipped weight by plant (top 10)? | Yes | Yes | Plant-13 1.84 M kg leads — values in millions of kg, consistent |
| Q8 | What is the on-time rate by carrier? | Yes | Yes | FedEx 75.8 % best; BlueDart 41.3 % worst — aligns with Q4 lead-time outlier |
| Q9 | What is the fill rate by customer segment? | Yes | Yes | Gold/Silver/Bronze all ~96.5 % — no segment bias, expected |
| Q10 | What is the order value by part category and region? | Yes | Yes | 15 rows (5 categories x 3 regions), Castings highest — coherent |
| Q11 | What is the on-time rate by supplier tier? | Yes | Yes | Tier 2 best (68.4 %), Tier 1 lowest (66.2 %) — small variance |
| Q12 | What is the lead time by plant city? | Yes | Yes | Pune 13.5 d, Bangkok 13.3 d — tight range across 5 cities |
| Q13 | What is the total weight by carrier? | Yes | Yes | Maersk 8.1 M kg leads; 4 carriers, balanced volumes |
| Q14 | What are total shipments by order month? | Yes | Yes | ~540-590/month for full months; Oct partial (14) — time-aware |
| Q15 | Which suppliers have the highest order value (top 10)? | Yes | Yes | Supplier 32 at $106 M leads — reasonable for 5 000 orders |
| Q16 | Which **vendors** have the best **service level**? *(synonym)* | Yes | Yes | Top vendor fill rate 0.997 — synonym "vendor"→SUPPLIER_NAME, "service level"→FILL_RATE |
| Q17 | How many **deliveries** per carrier? *(synonym)* | Yes | Yes | Maersk 1 282 leads — synonym "deliveries"→TOTAL_SHIPMENTS |
| Q18 | What is the **total spend** by **vendor country**? *(synonym)* | Yes | Yes | Thailand $909 M — synonym "total spend"→TOTAL_ORDER_VALUE_USD, "vendor country"→SUPPLIER_COUNTRY |
| Q19 | What is the **logistics on-time shipping rate** by carrier? *(ship-date)* | Yes | Yes | FedEx 92.6 % vs 75.8 % received-OTD — ship-date metric is higher as expected |
| Q20 | What is the **dispatch OTD** by plant (bottom 10)? *(ship-date)* | Yes | Yes | Plant-15 worst at 87.2 % — ship-date metric distinct from received-date, working correctly |

## Summary

| Metric | Value |
|--------|-------|
| Total questions | 20 |
| Ran successfully | 20 |
| Answer sensible | 20 |
| **Pass rate** | **20/20 (100 %)** |

### Coverage

- **Metrics exercised**: ON_TIME_RATE, ON_TIME_RATE_SHIP_DATE, FILL_RATE, AVG_LEAD_TIME_DAYS, TOTAL_ORDER_VALUE_USD, TOTAL_SHIPMENTS, TOTAL_WEIGHT_KG (all 7)
- **Dimensions exercised**: CUSTOMER_REGION, CUSTOMER_SEGMENT, SUPPLIER_NAME, SUPPLIER_COUNTRY, SUPPLIER_TIER, CARRIER, PLANT_NAME, PLANT_CITY, PART_CATEGORY, ORDER_MONTH (10 of 13)
- **Synonym questions**: Q16 (vendor, service level), Q17 (deliveries), Q18 (total spend, vendor country) — 3 of 3
- **Ship-date definition questions**: Q19 (logistics on-time shipping by carrier), Q20 (dispatch OTD by plant) — 2 of 2

### Key observations

1. **ON_TIME_RATE vs ON_TIME_RATE_SHIP_DATE clearly separated**: Q8 vs Q19 show FedEx at 75.8 % (received) vs 92.6 % (shipped) — the two definitions are distinct and both accessible.
2. **BlueDart outlier**: Consistently worst on both on-time metrics and has the highest lead time — the semantic view surfaces this correctly across multiple query angles.
3. **Synonym coverage works**: All three synonym-tagged questions correctly mapped to the intended metrics/dimensions.

### SQL pattern used

All queries use the `SEMANTIC_VIEW()` clause:

```sql
SELECT * FROM SEMANTIC_VIEW(
  SC_ONTOLOGY.SEMANTIC.SC_SEMANTIC_VIEW
  DIMENSIONS <table>.<dimension>
  METRICS <table>.<metric>
) ORDER BY ...
```
