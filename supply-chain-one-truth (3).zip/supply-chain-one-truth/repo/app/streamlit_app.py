import json
import re

import requests
import streamlit as st
from snowflake.snowpark.context import get_active_session

SEMANTIC_VIEW = "SC_ONTOLOGY.SEMANTIC.SC_SEMANTIC_VIEW"
LLM_MODEL = "claude-sonnet-4-6"

session = get_active_session()
st.set_page_config(page_title="Supply Chain: One Truth", layout="wide")
st.title("Supply Chain: One Truth")
st.caption("Governed conversational analytics on a supply chain ontology, built on Snowflake semantic views and Cortex Analyst.")

CATALOG = """
Semantic view: SC_ONTOLOGY.SEMANTIC.SC_SEMANTIC_VIEW
METRICS (always prefix with the logical table):
  shipments.on_time_rate            -- CERTIFIED on-time delivery (received date <= promised date). Default for any on-time question.
  shipments.on_time_rate_ship_date  -- Logistics-only definition (ship date <= promised date). Use only if the user asks for ship date / logistics.
  shipments.fill_rate               -- quantity shipped / quantity ordered
  shipments.total_shipments
  shipments.total_weight_kg         -- weight in kg
  shipments.avg_lead_time_days
  shipments.total_order_value_usd
DIMENSIONS:
  customers.customer_name, customers.customer_region, customers.customer_segment
  plants.plant_name, plants.plant_city
  parts.part_name, parts.part_category
  suppliers.supplier_name, suppliers.supplier_country, suppliers.supplier_tier
  shipments.carrier, shipments.order_month, shipments.order_quarter
"""


def _analyst_rest(question: str):
    """Preferred path: Cortex Analyst REST API using the current session token."""
    conn = session.connection
    url = f"https://{conn.host}/api/v2/cortex/analyst/message"
    headers = {
        "Authorization": f'Snowflake Token="{conn.rest.token}"',
        "Content-Type": "application/json",
    }
    body = {
        "messages": [{"role": "user", "content": [{"type": "text", "text": question}]}],
        "semantic_view": SEMANTIC_VIEW,
    }
    r = requests.post(url, headers=headers, json=body, timeout=60)
    r.raise_for_status()
    return r.json()["message"]["content"]


def _analyst_llm(question: str):
    """Fallback: Claude writes SQL against the governed semantic view only."""
    prompt = f"""You are a Snowflake SQL generator for a governed semantic layer.
{CATALOG}
Query pattern (the only allowed way to read data):
SELECT * FROM SEMANTIC_VIEW(
  SC_ONTOLOGY.SEMANTIC.SC_SEMANTIC_VIEW
  METRICS <metric list>
  DIMENSIONS <dimension list>
) [WHERE ...] [ORDER BY ...] [LIMIT ...]
Rules: use only the metrics and dimensions listed above. Never query raw tables.
Filters go in an outer WHERE using the dimension column names (without the table prefix).
Return ONLY the SQL statement, with no explanation and no markdown.

Question: {question}"""
    out = session.sql("SELECT SNOWFLAKE.CORTEX.COMPLETE(?, ?)", params=[LLM_MODEL, prompt]).collect()[0][0]
    sql = re.sub(r"```(?:sql)?", "", out).replace("```", "").strip().rstrip(";")
    return [
        {"type": "text", "text": "Answered from certified metrics in the governed semantic view."},
        {"type": "sql", "statement": sql},
    ]


def ask_analyst(question: str):
    try:
        return _analyst_rest(question)
    except Exception:
        return _analyst_llm(question)


def show_answer(items):
    for item in items:
        if item["type"] == "text":
            st.markdown(item["text"])
        elif item["type"] == "sql":
            with st.expander("Generated SQL", expanded=False):
                st.code(item["statement"], language="sql")
            df = session.sql(item["statement"].rstrip().rstrip(";")).to_pandas()
            df = df.drop(columns=[c for c in df.columns if c.upper() in ("START_DATE", "END_DATE")])
            for c in df.columns:
                if "RATE" in c.upper():
                    df[c] = (df[c].astype(float) * 100).round(1)
                    df = df.rename(columns={c: c + " (%)"})
            st.dataframe(df, use_container_width=True)
            if len(df) > 1 and len(df.columns) >= 2:
                num_cols = df.select_dtypes("number").columns.tolist()
                other = [c for c in df.columns if c not in num_cols]
                if num_cols and other:
                    st.bar_chart(df.set_index(other[0])[num_cols[0]])
        elif item["type"] == "suggestions":
            st.markdown("**Did you mean:** " + " | ".join(item["suggestions"]))


tab_chat, tab_truths, tab_defs = st.tabs(
    ["Ask a question", "Two Truths vs One Truth", "Metric definitions"]
)

# ---------------------------------------------------------------- chat
with tab_chat:
    examples = [
        "What was our on-time delivery rate by plant?",
        "Which suppliers have the lowest fill rate?",
        "Total weight shipped by carrier",
        "Average lead time by customer region",
    ]
    cols = st.columns(len(examples))
    clicked = None
    for col, ex in zip(cols, examples):
        if col.button(ex, use_container_width=True):
            clicked = ex

    question = st.chat_input("Ask about suppliers, plants, shipments, orders or customers") or clicked
    if question:
        st.chat_message("user").write(question)
        with st.chat_message("assistant"):
            try:
                with st.spinner("Thinking..."):
                    answer = ask_analyst(question)
                show_answer(answer)
            except Exception as e:
                st.error(f"Error: {e}")

# ---------------------------------------------------------- two truths
with tab_truths:
    st.subheader("Same question, different answers, until the ontology steps in")

    st.markdown("#### 1. What is our on-time delivery rate?")
    raw = session.sql(
        """
        SELECT
          ROUND(100*AVG(IFF(s.ship_date     <= o.promised_date,1,0)),1) AS logistics,
          ROUND(100*AVG(IFF(s.received_date <= o.promised_date,1,0)),1) AS sales
        FROM SC_ONTOLOGY.RAW.SHIPMENT s JOIN SC_ONTOLOGY.RAW.ORDERS o USING (order_id)
        """
    ).to_pandas().iloc[0]
    sem = session.sql(
        f"SELECT * FROM SEMANTIC_VIEW({SEMANTIC_VIEW} METRICS shipments.on_time_rate)"
    ).to_pandas().iloc[0, 0]
    c1, c2, c3 = st.columns(3)
    c1.metric("Logistics says (ship date)", f"{raw['LOGISTICS']}%")
    c2.metric("Sales says (received date)", f"{raw['SALES']}%")
    c3.metric("Ontology: certified answer", f"{float(sem)*100:.1f}%")
    st.info("Certified definition: share of shipments RECEIVED on or before the promised date.")

    st.markdown("#### 2. How many suppliers do we have?")
    sup = session.sql(
        """
        SELECT (SELECT COUNT(DISTINCT supplier_id) FROM SC_ONTOLOGY.RAW.SHIPMENT) AS raw_ids,
               (SELECT COUNT(DISTINCT canonical_supplier_id) FROM SC_ONTOLOGY.RAW.SHIPMENT_FACTS) AS canonical
        """
    ).to_pandas().iloc[0]
    c1, c2 = st.columns(2)
    c1.metric("Raw supplier IDs in shipments", int(sup["RAW_IDS"]))
    c2.metric("Real suppliers (ontology)", int(sup["CANONICAL"]))

    st.markdown("#### 3. How much did we ship (weight)?")
    w = session.sql(
        """
        SELECT (SELECT SUM(shipment_weight) FROM SC_ONTOLOGY.RAW.SHIPMENT) AS naive,
               (SELECT SUM(weight_kg) FROM SC_ONTOLOGY.RAW.SHIPMENT_FACTS) AS normalized
        """
    ).to_pandas().iloc[0]
    c1, c2 = st.columns(2)
    c1.metric("Naive sum (kg and lb mixed)", f"{w['NAIVE']:,.0f}")
    c2.metric("Ontology: total in kg", f"{w['NORMALIZED']:,.0f}")

# ----------------------------------------------------------- definitions
with tab_defs:
    st.subheader("Governed metric definitions")
    st.table(
        {
            "Metric": ["on_time_rate", "on_time_rate_ship_date", "fill_rate", "total_weight_kg", "avg_lead_time_days"],
            "Status": ["Certified", "Logistics-only", "Certified", "Certified", "Certified"],
            "Definition": [
                "Shipments received on or before the promised date",
                "Shipments shipped on or before the promised date (not customer-facing)",
                "Quantity shipped / quantity ordered",
                "Shipped weight in kg (lb converted)",
                "Days from order date to received date",
            ],
        }
    )
    st.markdown("**Entity model:** Supplier -> Part -> Plant -> Shipment -> Order -> Customer")
    st.graphviz_chart(
        """
        digraph { rankdir=LR; node [shape=box, style=rounded];
          Supplier -> Shipment; Part -> Order; Plant -> Order; Order -> Shipment; Customer -> Order; }
        """
    )