# Supply Chain: One Truth

**Governed conversational analytics on a supply chain ontology, built on Snowflake.**
Hackathon problem statement: *Supply Chain Ontology and Governed Conversational Analytics*.

## The problem

Supply chain data is scattered across ERP, logistics and supplier systems with inconsistent definitions, so the same question gets different answers from different teams. In our data:

| Question | Logistics says | Sales says | Ontology (one truth) |
|---|---|---|---|
| On-time delivery rate | 91.4% (ship date) | 66.9% (received date) | **66.9%**, with the definition shown |
| How many suppliers? | 46 supplier IDs | | **40** real suppliers (name variants merged) |
| Total weight shipped | ~51.0M (kg and lb mixed) | | **~31.8M kg** |

## The solution

An ontology expressed as a governed Snowflake **semantic view**, with a natural language layer on top. Every question is answered from certified metric definitions, never from ad-hoc SQL on raw tables.

**Entity model:** Supplier -> Part -> Plant -> Shipment -> Order -> Customer

**Certified metrics:** on-time rate (received date), fill rate, total weight (kg), average lead time, order value. The Logistics ship-date definition is kept as a clearly labelled alternative metric.

## Architecture

```mermaid
flowchart LR
  A[RAW tables<br/>Orders, Shipment, Supplier,<br/>Part, Plant, Customer] --> B[Reconciliation views<br/>CANONICAL_SUPPLIER<br/>SHIPMENT_FACTS]
  B --> C[Semantic view<br/>SC_SEMANTIC_VIEW<br/>entities, relationships,<br/>certified metrics]
  C --> D[Cortex Analyst]
  D --> E[Streamlit app<br/>chat, Two Truths,<br/>metric definitions]
  A -. masking policy .-> B
```

## Conflicts planted and resolved

1. **Duplicate suppliers:** name variants ("Pvt Ltd" vs "PRIVATE LIMITED") are merged into one canonical supplier.
2. **Two definitions of "on time":** ship date vs received date. One is certified, the other is labelled Logistics-only.
3. **Mixed units:** weight is recorded in kg at some plants and lb at others. All weights are normalized to kg.

## Governance

A masking policy hides `unit_price_usd` from everyone except `PROCUREMENT_ROLE` (and admin). The same order-value question returns a number for Procurement and `NULL` for Analyst.

## App

Streamlit app with three tabs:
- **Ask a question:** chat over the semantic view, with generated SQL and charts.
- **Two Truths vs One Truth:** side-by-side proof of the conflicts and their resolution.
- **Metric definitions:** certified metrics and the entity model.

## How we used Snowflake CoCo CLI

We used CoCo CLI to audit our semantic view. It discovered the schema objects, reviewed synonyms and metric definitions, and found a collision where the synonym "tier" was attached to both customer segment and supplier tier. With CoCo we fixed that collision, added 12 synonym improvements and guardrail aliases separating the certified on-time metric from the Logistics ship-date metric, and added 4 verified queries. We backed up the DDL first, applied the change with `COPY GRANTS`, and CoCo verified that structure and grants were unchanged afterwards.

CoCo also wrote and executed a 20-query test set against the semantic view (all 7 metrics, 10 of 13 dimensions, synonym and ship-date definition questions): 20/20 executed with plausible results. See `docs/semantic_view_test_results.md`. Note that CoCo wrote the SQL for these tests, so they validate the semantic view itself, not Cortex Analyst's free-text translation.

## Run it

Run in a Snowsight SQL worksheet as ACCOUNTADMIN, in this order:

1. `sql/01_setup_and_data.sql` - account setup, synthetic data, planted conflicts
2. `sql/02_semantic_view.sql` - reconciliation views and the base semantic view
3. `sql/03_signals_and_masking.sql` - demo signals, roles, masking policy
4. `sql/05_semantic_view_final.sql` - the CoCo-reviewed semantic view (synonyms and verified queries)
5. Create a Streamlit app in `SC_ONTOLOGY.APP` using `app/streamlit_app.py`

## Links

- Demo video: <add link>
- Deck: `docs/Supply_Chain_One_Truth_Deck.pdf`

## Data note

All data is fully synthetic, generated in SQL.
