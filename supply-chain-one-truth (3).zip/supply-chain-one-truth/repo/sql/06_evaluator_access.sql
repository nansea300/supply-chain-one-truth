-- =====================================================================
-- Evaluator access: run AFTER you have deployed the Streamlit app and
-- AFTER the two evaluators have accepted their Snowflake invitations.
-- Fill in the <PLACEHOLDERS> first.
-- =====================================================================
USE ROLE ACCOUNTADMIN;

-- 1. Find the exact name of your deployed Streamlit app
SHOW STREAMLITS IN DATABASE SC_ONTOLOGY;

-- 2. Let the two demo roles open the app
GRANT USAGE ON SCHEMA SC_ONTOLOGY.APP TO ROLE ANALYST_ROLE;
GRANT USAGE ON SCHEMA SC_ONTOLOGY.APP TO ROLE PROCUREMENT_ROLE;
GRANT USAGE ON STREAMLIT SC_ONTOLOGY.APP.<APP_NAME> TO ROLE ANALYST_ROLE;
GRANT USAGE ON STREAMLIT SC_ONTOLOGY.APP.<APP_NAME> TO ROLE PROCUREMENT_ROLE;

-- 3. Give each evaluator BOTH demo roles, so they can switch roles and see
--    the masking policy work (Procurement sees price, Analyst does not).
--    Usernames are shown under Admin > Users & Roles once they accept the invite.
GRANT ROLE PROCUREMENT_ROLE TO USER <EVALUATOR_1_USERNAME>;
GRANT ROLE ANALYST_ROLE     TO USER <EVALUATOR_1_USERNAME>;
GRANT ROLE PROCUREMENT_ROLE TO USER <EVALUATOR_2_USERNAME>;
GRANT ROLE ANALYST_ROLE     TO USER <EVALUATOR_2_USERNAME>;

-- 4. Check
SHOW GRANTS TO ROLE PROCUREMENT_ROLE;
SHOW GRANTS ON STREAMLIT SC_ONTOLOGY.APP.<APP_NAME>;
