-- SC_ONTOLOGY.SEMANTIC.SC_SEMANTIC_VIEW — Final DDL
-- Exported via GET_DDL on 2026-10-05
-- Includes: synonym patches, ON_TIME_RATE guardrails, 4 verified queries

create or replace semantic view SC_SEMANTIC_VIEW
	tables (
		SHIPMENTS as SC_ONTOLOGY.RAW.SHIPMENT_FACTS primary key (SHIPMENT_ID) comment='One row per shipment, joined to its order. Core fact table.',
		CUSTOMERS as SC_ONTOLOGY.RAW.CUSTOMER primary key (CUSTOMER_ID) comment='Customers who place orders.',
		PLANTS as SC_ONTOLOGY.RAW.PLANT primary key (PLANT_ID) comment='Manufacturing or fulfilment plants.',
		PARTS as SC_ONTOLOGY.RAW.PART primary key (PART_ID) comment='Parts that are ordered and shipped.',
		SUPPLIERS as SC_ONTOLOGY.RAW.CANONICAL_SUPPLIER primary key (CANONICAL_SUPPLIER_ID) comment='De-duplicated suppliers. Name variants are resolved to one canonical supplier.'
	)
	relationships (
		SHIPMENTS_TO_CUSTOMERS as SHIPMENTS(CUSTOMER_ID) references CUSTOMERS(CUSTOMER_ID),
		SHIPMENTS_TO_PARTS as SHIPMENTS(PART_ID) references PARTS(PART_ID),
		SHIPMENTS_TO_PLANTS as SHIPMENTS(PLANT_ID) references PLANTS(PLANT_ID),
		SHIPMENTS_TO_SUPPLIERS as SHIPMENTS(CANONICAL_SUPPLIER_ID) references SUPPLIERS(CANONICAL_SUPPLIER_ID)
	)
	dimensions (
		SHIPMENTS.CARRIER as shipments.carrier with synonyms=('logistics provider','transporter','shipping company','freight carrier'),
		SHIPMENTS.ORDER_MONTH as DATE_TRUNC('month', shipments.order_date) with synonyms=('month','order month','monthly'),
		SHIPMENTS.ORDER_QUARTER as DATE_TRUNC('quarter', shipments.order_date) with synonyms=('quarter','order quarter','quarterly'),
		CUSTOMERS.CUSTOMER_NAME as customers.customer_name with synonyms=('client','account'),
		CUSTOMERS.CUSTOMER_REGION as customers.region with synonyms=('region','market','geography'),
		CUSTOMERS.CUSTOMER_SEGMENT as customers.segment with synonyms=('customer tier','customer segment','customer class'),
		PLANTS.PLANT_NAME as plants.plant_name with synonyms=('factory','site'),
		PLANTS.PLANT_CITY as plants.city with synonyms=('location','city','plant location','manufacturing city'),
		PARTS.PART_NAME as parts.part_name with synonyms=('product','component','SKU','item'),
		PARTS.PART_CATEGORY as parts.category with synonyms=('product category','commodity'),
		SUPPLIERS.SUPPLIER_NAME as suppliers.supplier_name with synonyms=('vendor','supplier','vendor name','supplier name') comment='Canonical supplier name (duplicates merged).',
		SUPPLIERS.SUPPLIER_COUNTRY as suppliers.country with synonyms=('vendor country','sourcing country'),
		SUPPLIERS.SUPPLIER_TIER as suppliers.tier with synonyms=('vendor tier','supplier level','tier level')
	)
	metrics (
		SHIPMENTS.ON_TIME_RATE as AVG(shipments.on_time_received_flag) with synonyms=('OTD','on-time delivery','on time delivery rate','delivery performance','delivery reliability') comment='CERTIFIED definition: share of shipments RECEIVED by the customer on or before the promised date. Use this for any on-time question.',
		SHIPMENTS.ON_TIME_RATE_SHIP_DATE as AVG(shipments.on_time_ship_flag) with synonyms=('logistics on-time rate','on-time shipping','OTD ship','dispatch OTD','dispatch performance','outbound on-time') comment='Logistics team definition: share of shipments SHIPPED on or before the promised date. Not customer-facing. Differs from certified on_time_rate.',
		SHIPMENTS.FILL_RATE as SUM(shipments.qty_shipped) / NULLIF(SUM(shipments.qty_ordered), 0) with synonyms=('order fill rate','quantity fulfilment','fulfillment rate','fill percentage','service level') comment='Quantity shipped divided by quantity ordered.',
		SHIPMENTS.TOTAL_SHIPMENTS as COUNT(shipments.shipment_id) with synonyms=('shipment count','number of shipments','deliveries','delivery count'),
		SHIPMENTS.TOTAL_WEIGHT_KG as SUM(shipments.weight_kg) with synonyms=('total weight','tonnage','shipped weight','shipment weight') comment='Total shipped weight in kilograms. Pounds recorded at some plants are converted to kg.',
		SHIPMENTS.AVG_LEAD_TIME_DAYS as AVG(shipments.lead_time_days) with synonyms=('lead time','average lead time','order to delivery days') comment='Average days from order date to received date.',
		SHIPMENTS.TOTAL_ORDER_VALUE_USD as SUM(shipments.qty_ordered * shipments.unit_price_usd) with synonyms=('order value','revenue','sales value','total spend','order amount','purchase value')
	)
	comment='Supply chain ontology: Supplier -> Part -> Plant -> Shipment -> Order -> Customer, with one certified definition per metric.'
	ai_verified_queries (
		VQR_WORST_FILL_RATE AS ( 
QUESTION 'Which suppliers have the worst fill rate?' 
SQL 'SELECT
              suppliers.supplier_name AS supplier_name,
              SUM(shipments.qty_shipped) / NULLIF(SUM(shipments.qty_ordered), 0) AS fill_rate
           FROM SC_ONTOLOGY.RAW.SHIPMENT_FACTS shipments
           JOIN SC_ONTOLOGY.RAW.CANONICAL_SUPPLIER suppliers
             ON shipments.canonical_supplier_id = suppliers.canonical_supplier_id
           GROUP BY suppliers.supplier_name
           ORDER BY fill_rate ASC
           LIMIT 10'),
		VQR_LEAD_TIME_BY_CARRIER AS ( 
QUESTION 'What is the average lead time by carrier?' 
SQL 'SELECT
              shipments.carrier AS carrier,
              AVG(shipments.lead_time_days) AS avg_lead_time_days
           FROM SC_ONTOLOGY.RAW.SHIPMENT_FACTS shipments
           GROUP BY shipments.carrier
           ORDER BY avg_lead_time_days DESC'),
		VQR_OTD_BY_SEGMENT AS ( 
QUESTION 'Compare on-time rate across Gold, Silver, and Bronze customers' 
SQL 'SELECT
              customers.segment AS customer_segment,
              AVG(shipments.on_time_received_flag) AS on_time_rate
           FROM SC_ONTOLOGY.RAW.SHIPMENT_FACTS shipments
           JOIN SC_ONTOLOGY.RAW.CUSTOMER customers
             ON shipments.customer_id = customers.customer_id
           GROUP BY customers.segment
           ORDER BY on_time_rate DESC'),
		VQR_REVENUE_BY_CATEGORY_EMEA AS ( 
QUESTION 'What is the revenue split by part category for EMEA?' 
SQL 'SELECT
              parts.category AS part_category,
              SUM(shipments.qty_ordered * shipments.unit_price_usd) AS total_order_value_usd
           FROM SC_ONTOLOGY.RAW.SHIPMENT_FACTS shipments
           JOIN SC_ONTOLOGY.RAW.PART parts
             ON shipments.part_id = parts.part_id
           JOIN SC_ONTOLOGY.RAW.CUSTOMER customers
             ON shipments.customer_id = customers.customer_id
           WHERE customers.region = ''EMEA''
           GROUP BY parts.category
           ORDER BY total_order_value_usd DESC')
	);
