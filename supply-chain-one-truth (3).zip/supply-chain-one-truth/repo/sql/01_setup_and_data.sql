
USE ROLE ACCOUNTADMIN;

ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';

CREATE WAREHOUSE IF NOT EXISTS SC_WH
WAREHOUSE_SIZE = 'XSMALL' AUTO_SUSPEND = 60 AUTO_RESUME = TRUE;
USE WAREHOUSE SC_WH;

CREATE DATABASE IF NOT EXISTS SC_ONTOLOGY;
CREATE SCHEMA IF NOT EXISTS SC_ONTOLOGY.RAW;
CREATE SCHEMA IF NOT EXISTS SC_ONTOLOGY.SEMANTIC;
CREATE SCHEMA IF NOT EXISTS SC_ONTOLOGY.APP;
USE SCHEMA SC_ONTOLOGY.RAW;

-- 2. Dimension tables ----------------------------------------------------
CREATE OR REPLACE TABLE PLANT AS
SELECT SEQ4()+1 AS plant_id,
       'Plant-' || LPAD(SEQ4()+1, 2, '0') AS plant_name,
       ARRAY_CONSTRUCT('Bengaluru','Pune','Chennai','Bangkok','Singapore')[UNIFORM(0,4,RANDOM())]::STRING AS city
FROM TABLE(GENERATOR(ROWCOUNT => 20));

CREATE OR REPLACE TABLE CUSTOMER AS
SELECT SEQ4()+1 AS customer_id,
       'Customer ' || (SEQ4()+1) AS customer_name,
       ARRAY_CONSTRUCT('APAC','EMEA','AMER')[UNIFORM(0,2,RANDOM())]::STRING AS region,
       ARRAY_CONSTRUCT('Gold','Silver','Bronze')[UNIFORM(0,2,RANDOM())]::STRING AS segment
FROM TABLE(GENERATOR(ROWCOUNT => 200));

CREATE OR REPLACE TABLE PART AS
SELECT SEQ4()+1 AS part_id,
       'Part-' || LPAD(SEQ4()+1, 4, '0') AS part_name,
       ARRAY_CONSTRUCT('Electronics','Fasteners','Castings','Hydraulics','Packaging')[UNIFORM(0,4,RANDOM())]::STRING AS category,
       ROUND(UNIFORM(1,50,RANDOM())::FLOAT, 1) AS unit_weight_kg
FROM TABLE(GENERATOR(ROWCOUNT => 100));

-- PLANTED CONFLICT 1: duplicate suppliers with name variants
CREATE OR REPLACE TABLE SUPPLIER AS
SELECT 'S' || LPAD(SEQ4()+1, 4, '0') AS supplier_id,
       'Supplier ' || (SEQ4()+1) || ' Pvt Ltd' AS supplier_name,
       ARRAY_CONSTRUCT('India','Thailand','Vietnam','China','Germany')[UNIFORM(0,4,RANDOM())]::STRING AS country,
       UNIFORM(1,3,RANDOM()) AS tier
FROM TABLE(GENERATOR(ROWCOUNT => 40));

INSERT INTO SUPPLIER
SELECT 'S' || LPAD(100 + ROW_NUMBER() OVER (ORDER BY supplier_id), 4, '0'),
       UPPER(REPLACE(supplier_name, 'Pvt Ltd', 'PRIVATE LIMITED')),
       country, tier
FROM SUPPLIER WHERE supplier_id <= 'S0006';

CREATE OR REPLACE TABLE SUPPLIER_CANONICAL AS
SELECT supplier_id,
       CASE WHEN supplier_id >= 'S0101'
            THEN 'S' || LPAD(TO_NUMBER(SUBSTR(supplier_id,2)) - 100, 4, '0')
            ELSE supplier_id END AS canonical_supplier_id
FROM SUPPLIER;

-- 3. Fact tables ---------------------------------------------------------
CREATE OR REPLACE TABLE ORDERS AS
WITH base AS (
  SELECT SEQ4()+1 AS order_id,
         UNIFORM(1,200,RANDOM()) AS customer_id,
         UNIFORM(1,20,RANDOM())  AS plant_id,
         UNIFORM(1,100,RANDOM()) AS part_id,
         UNIFORM(10,500,RANDOM()) AS qty_ordered,
         UNIFORM(100,5000,RANDOM()) AS unit_price_usd,
         DATEADD(day, -UNIFORM(0,270,RANDOM()), CURRENT_DATE()) AS order_date
  FROM TABLE(GENERATOR(ROWCOUNT => 5000))
)
SELECT *, DATEADD(day, UNIFORM(7,14,RANDOM()), order_date) AS promised_date FROM base;

-- PLANTED CONFLICT 2: two date columns -> two definitions of "on time"
-- PLANTED CONFLICT 3: weight in kg at some plants, lb at others
CREATE OR REPLACE TABLE SHIPMENT AS
WITH s AS (
  SELECT o.order_id, o.plant_id, o.qty_ordered, o.promised_date, p.unit_weight_kg,
         'S' || LPAD(UNIFORM(1,40,RANDOM()), 4, '0') AS supplier_id,
         DATEADD(day, UNIFORM(-3,3,RANDOM()), o.promised_date) AS ship_date
  FROM ORDERS o JOIN PART p ON o.part_id = p.part_id
)
SELECT order_id AS shipment_id, order_id, plant_id, supplier_id,
       ARRAY_CONSTRUCT('BlueDart','DHL','Maersk','FedEx')[UNIFORM(0,3,RANDOM())]::STRING AS carrier,
       ship_date,
       DATEADD(day, UNIFORM(1,6,RANDOM()), ship_date) AS received_date,
       IFF(UNIFORM(0,9,RANDOM()) = 0, FLOOR(qty_ordered * 0.9), qty_ordered) AS qty_shipped,
       IFF(MOD(plant_id,2)=0, qty_ordered * unit_weight_kg, qty_ordered * unit_weight_kg * 2.2046) AS shipment_weight,
       IFF(MOD(plant_id,2)=0, 'KG', 'LB') AS weight_uom
FROM s;

-- 4. Realism fix: on-time rates of roughly 92% (Logistics) vs 75-80% (Sales) -
UPDATE ORDERS SET promised_date = DATEADD(day, UNIFORM(10,20,RANDOM()), order_date);

UPDATE SHIPMENT s SET ship_date = DATEADD(day, UNIFORM(-10,1,RANDOM()), o.promised_date)
FROM ORDERS o WHERE s.order_id = o.order_id;

UPDATE SHIPMENT SET received_date = DATEADD(day, UNIFORM(1,3,RANDOM()), ship_date);

-- 5. Verification (run these last) ----------------------------------------
-- 5a. Row counts: expect 20, 200, 100, 46, 5000, 5000
SELECT 'PLANT' t, COUNT(*) n FROM PLANT UNION ALL
SELECT 'CUSTOMER', COUNT(*) FROM CUSTOMER UNION ALL
SELECT 'PART', COUNT(*) FROM PART UNION ALL
SELECT 'SUPPLIER', COUNT(*) FROM SUPPLIER UNION ALL
SELECT 'ORDERS', COUNT(*) FROM ORDERS UNION ALL
SELECT 'SHIPMENT', COUNT(*) FROM SHIPMENT;

-- 5b. "Two Truths": same question, two answers
SELECT 'Logistics (ship date)' AS team,
       ROUND(100 * AVG(IFF(s.ship_date <= o.promised_date, 1, 0)), 1) AS on_time_pct
FROM SHIPMENT s JOIN ORDERS o USING (order_id)
UNION ALL
SELECT 'Sales (received date)',
       ROUND(100 * AVG(IFF(s.received_date <= o.promised_date, 1, 0)), 1)
FROM SHIPMENT s JOIN ORDERS o USING (order_id);

-- 5c. Cortex sanity check (should return text, not an error)
SELECT SNOWFLAKE.CORTEX.COMPLETE('claude-sonnet-4-6', 'Say OK');
